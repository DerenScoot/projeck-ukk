﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_deren_mesin_kasir
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void produkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 newMenu = new Form3();
            newMenu.ShowDialog();
            this.Close();            this.Hide();

        }

        private void masterKategoriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 newMenu = new Form5();
            this.Hide();
            newMenu.ShowDialog();
            this.Close();
        }

        private void tambahToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 newMenu = new Form2();
            this.Hide();
            newMenu.ShowDialog();
            this.Close();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Reset();

            Form2 newMenu = new Form2();
            this.Hide();
            newMenu.ShowDialog();
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void produkToolStripMenuItem_(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void masterProdukToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
    }
}
